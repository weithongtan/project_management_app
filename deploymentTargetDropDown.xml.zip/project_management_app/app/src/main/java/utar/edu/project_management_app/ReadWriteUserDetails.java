package utar.edu.project_management_app;

public class ReadWriteUserDetails {
    public String username;

    public ReadWriteUserDetails(){}
    public ReadWriteUserDetails(String username){
        this.username = username;
    }
}
